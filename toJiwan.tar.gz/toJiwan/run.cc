#include "eg6_pass2.C"


void run()
{
  eg6_pass2 t;
  t.Loop();
}
